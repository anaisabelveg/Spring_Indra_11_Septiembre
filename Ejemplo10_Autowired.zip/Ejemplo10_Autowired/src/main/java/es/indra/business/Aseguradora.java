package es.indra.business;

import es.indra.models.Coche;

public class Aseguradora {

	private String nombre;
	private ITaller taller;   // Inyeccion de dependencias
	
	public void arreglarCoche(Coche coche) {
		taller.reparar(coche);
	}

	// Spring necesita los metodos de acceso (getter y setter) para inyectar
	// propiedades
	public String getNombre() {
		return nombre;
	}

	public void setNombre(String nombre) {
		this.nombre = nombre;
	}

	public ITaller getTaller() {
		return taller;
	}

	public void setTaller(ITaller taller) {
		this.taller = taller;
	}

}
