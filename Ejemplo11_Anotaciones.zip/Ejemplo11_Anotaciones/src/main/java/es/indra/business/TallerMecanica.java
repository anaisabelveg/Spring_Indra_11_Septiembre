package es.indra.business;

import org.springframework.stereotype.Service;

import es.indra.models.Coche;

@Service("tallerMecanica")
public class TallerMecanica implements ITaller{

	public void reparar(Coche coche) {
		System.out.println("En el taller de mecanica se repara el coche " + coche);
		
	}

}
