package es.indra.business;

import org.springframework.context.annotation.Primary;
import org.springframework.stereotype.Service;

import es.indra.models.Coche;

// Si no pongo ningun nombre, tomara el nombre de la clase comenzando en minuscula
@Service
@Primary    // Doy preferencia a este bean en la DI
public class TallerPintura implements ITaller{

	public void reparar(Coche coche) {
		System.out.println("En el taller de pintura, se repara el coche " + coche);
		
	}

}
