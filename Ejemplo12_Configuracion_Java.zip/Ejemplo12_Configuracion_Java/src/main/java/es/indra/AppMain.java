package es.indra;

import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;

import es.indra.business.Aseguradora;
import es.indra.config.ClaseConfiguracion;
import es.indra.models.Coche;

public class AppMain {

	public static void main(String[] args) {
		// Levantar el contexto de Spring
		// Leer ClaseConfiguracion y por cada bean declarado genera
		// la instancia y la guarda en el contenedor
		ApplicationContext appCtx = new AnnotationConfigApplicationContext(ClaseConfiguracion.class);
		
		// Recuperar el bean coche
		Coche coche = (Coche) appCtx.getBean("coche");
		
		// Recuperar el bean aseguradora
		Aseguradora aseguradora = appCtx.getBean("aseguradora", Aseguradora.class);
		
		aseguradora.arreglarCoche(coche);

	}

}
