package es.indra.config;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import es.indra.business.Aseguradora;
import es.indra.business.TallerMecanica;
import es.indra.business.TallerPintura;
import es.indra.models.Coche;

@Configuration
public class ClaseConfiguracion {
	
	// El nombre del metodo es el identificador del bean
	@Bean
	public TallerPintura tallerPintura() {
		return new TallerPintura();
	}
	
	@Bean
	public TallerMecanica tallerMecanica() {
		return new TallerMecanica();
	}
	
	@Bean
	public Coche coche() {
		return new Coche("1234-MBD", "A5");
	}
	
	@Bean
	public Aseguradora aseguradora() {
		Aseguradora aseguradora = new Aseguradora();
		aseguradora.setNombre("Mapfre");
		aseguradora.setTaller(tallerPintura()); 
		return aseguradora;
	}

}
