package es.indra;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import es.indra.business.Pruebas;

public class AppMain {

	public static void main(String[] args) {
		// Levantar el contexto de Spring
		// Leer applicationContext.xml y por cada bean declarado genera
		// la instancia y la guarda en el contenedor
		ApplicationContext appCtx = new ClassPathXmlApplicationContext("applicationContext.xml");
		
		System.out.println(appCtx.getBean("cliente1"));
		System.out.println(appCtx.getBean("cliente2"));
		
		Pruebas pruebas = appCtx.getBean("pruebas", Pruebas.class);
		System.out.println("Contador: " + pruebas.getValorContador());
		System.out.println("Importe de compras: " + pruebas.getImporteCompras());
		System.out.println("Clientes:");
		pruebas.getClientes().forEach(System.out::println);
		
		Pruebas pruebas2 = appCtx.getBean("pruebas2", Pruebas.class);
		System.out.println("Mejores clientes:");
		pruebas2.getMejoresClientes().forEach(System.out::println);
		System.out.println("Datos: ");
		pruebas2.getDatos().forEach(System.out::println);

	}

}
