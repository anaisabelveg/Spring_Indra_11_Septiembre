package es.indra.business;

public class Vacaciones {
	
	public void viajar() {
		System.out.println("Nos vamos de vacaciones");
	}

}
