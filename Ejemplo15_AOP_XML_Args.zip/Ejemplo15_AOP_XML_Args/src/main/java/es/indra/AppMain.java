package es.indra;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import es.indra.business.Vacaciones;

public class AppMain {

	public static void main(String[] args) {
		// Levantar el contexto de Spring
		// Leer applicationContext.xml y por cada bean declarado genera
		// la instancia y la guarda en el contenedor
		ApplicationContext appCtx = new ClassPathXmlApplicationContext("applicationContext.xml");
		
		Vacaciones vacaciones = appCtx.getBean("vacaciones", Vacaciones.class);
		vacaciones.viajar("IB-1234");

	}

}
