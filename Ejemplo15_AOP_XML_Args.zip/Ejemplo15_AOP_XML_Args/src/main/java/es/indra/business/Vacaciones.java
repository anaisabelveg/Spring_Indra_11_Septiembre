package es.indra.business;

public class Vacaciones {
	
	public void viajar(String numVuelo) throws RuntimeException{
		System.out.println("Nos vamos de vacaciones en el vuelo " + numVuelo);
		//throw new RuntimeException("Problemassss");
	}

}
