package es.indra.business;

import org.springframework.stereotype.Service;

@Service
public class Vacaciones {
	
	public void viajar() throws RuntimeException{
		System.out.println("Nos vamos de vacaciones");
		throw new RuntimeException("Problemassss");
	}

}
