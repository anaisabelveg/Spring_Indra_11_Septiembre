package es.indra.utils;

import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.annotation.After;
import org.aspectj.lang.annotation.AfterReturning;
import org.aspectj.lang.annotation.AfterThrowing;
import org.aspectj.lang.annotation.Around;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Before;
import org.aspectj.lang.annotation.Pointcut;
import org.springframework.core.annotation.Order;
import org.springframework.stereotype.Service;

@Service
@Aspect
//@Order(value = 1)
public class Aspectos {
	
	//@Pointcut("bean(vacaciones)")
	@Pointcut("execution (* es.indra.business.Vacaciones.viajar(..))")
	public void viajar() {}
	
	// Si hay consejos iguales los ordena alfabeticamente
	// Si quiero llevar mi orden (a, b, c, d, .....)
	// Otra alternativa es crear diferentes clases de aspectos y establecer un orden
	@Before("viajar()")
	public void afacturar() {
		System.out.println("Facturando");
	}
	
	/* Otras formas de aplicar los aspectos
	 * @Before(value="execution (* es.indra.business.Vacaciones.viajar(..))")
	 * @Before("bean(vacaciones)")
	 * @Before("bean(*DAO)")
	 * */
	
	@Before("viajar()")
	public void bpasarControl() {
		System.out.println("Pasando el control");
	}
	
	@Before("viajar()")
	public void cembarcar() {
		System.out.println("Embarcando");
	}
	
	@Before("viajar()")
	public void ddespegar() {
		System.out.println("Despegando");
	}
	
	@After("viajar()")
	public void aterrizar() {
		System.out.println("Aterrizando");
	}
	
	@AfterReturning("viajar()")
	public void recogerEquipaje() {
		System.out.println("Recogiendo el equipaje");
	}
	
	@AfterThrowing(pointcut = "viajar()", throwing = "ex")
	public void emergencia(Exception ex) {
		System.out.println("Huston tenemos un problema");
		System.out.println(ex.getMessage());
	}
	
	@Around("viajar()")
	public void medirTiempo(ProceedingJoinPoint pjp) {
		// antes
		long inicio = System.currentTimeMillis();
		System.out.println("Tomando tiempo de inicio");
		
		try {
			pjp.proceed();   // Se invoca al metodo viajar()
		} catch (Throwable e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		// despues
		long fin = System.currentTimeMillis();
		System.out.println("Tomando el tiempo final");
		System.out.println("duracion: " + (fin-inicio) + "mseg.");
	}

}




