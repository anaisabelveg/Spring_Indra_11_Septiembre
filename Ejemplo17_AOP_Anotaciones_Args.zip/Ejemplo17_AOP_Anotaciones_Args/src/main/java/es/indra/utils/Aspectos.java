package es.indra.utils;

import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.annotation.After;
import org.aspectj.lang.annotation.AfterReturning;
import org.aspectj.lang.annotation.AfterThrowing;
import org.aspectj.lang.annotation.Around;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Before;
import org.aspectj.lang.annotation.Pointcut;
import org.springframework.core.annotation.Order;
import org.springframework.stereotype.Service;

@Service
@Aspect
//@Order(value = 1)
public class Aspectos {
	
	// Como no puedo poner mas de un punto de corte en la clase,
	// los declaro sobre cada aspecto
	
	@Before(value="execution (* es.indra.business.Vacaciones.viajar(..)) && args(nVuelo) ")
	public void afacturar(String nVuelo) {
		System.out.println("Facturando " + nVuelo);
	}
	
	@Before(value="execution (* es.indra.business.Vacaciones.viajar(..))")
	public void bpasarControl() {
		System.out.println("Pasando el control");
	}
	
	@Before(value="execution (* es.indra.business.Vacaciones.viajar(..)) && args(numeroVuelo) ")
	public void cembarcar(String numeroVuelo) {
		System.out.println("Embarcando " + numeroVuelo);
	}
	
	@Before(value="execution (* es.indra.business.Vacaciones.viajar(..))")
	public void ddespegar() {
		System.out.println("Despegando");
	}
	
	@After(value="execution (* es.indra.business.Vacaciones.viajar(..))")
	public void aterrizar() {
		System.out.println("Aterrizando");
	}
	
	@AfterReturning(value="execution (* es.indra.business.Vacaciones.viajar(..))")
	public void recogerEquipaje() {
		System.out.println("Recogiendo el equipaje");
	}
	
	// De esta forma no funciona
	//@AfterThrowing(value="execution(* es.indra.business.Vacaciones.viajar(..)) && args(ex)")
	
	@AfterThrowing(pointcut = "execution(* es.indra.business.Vacaciones.viajar(..))", throwing = "ex")
	public void emergencia(Exception ex) {
		System.out.println("Huston tenemos un problema");
		System.out.println(ex.getMessage());
	}
	
	@Around(value="execution (* es.indra.business.Vacaciones.viajar(..))")
	public void medirTiempo(ProceedingJoinPoint pjp) {
		// antes
		long inicio = System.currentTimeMillis();
		System.out.println("Tomando tiempo de inicio");
		
		try {
			pjp.proceed();   // Se invoca al metodo viajar()
		} catch (Throwable e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		// despues
		long fin = System.currentTimeMillis();
		System.out.println("Tomando el tiempo final");
		System.out.println("duracion: " + (fin-inicio) + "mseg.");
	}

}




