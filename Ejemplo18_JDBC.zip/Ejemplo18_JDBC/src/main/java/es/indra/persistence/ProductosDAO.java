package es.indra.persistence;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import es.indra.models.Producto;

public class ProductosDAO {
	
	private Connection con;
	
	public List<Producto> consultarTodos(){
		List<Producto> lista = new ArrayList<Producto>();
		
		try {
			abrirConexion();
			
			String sql = "select * from PRODUCTOS";
			Statement stm = con.createStatement();
			ResultSet rs = stm.executeQuery(sql);
			
			while (rs.next()) {
				lista.add(new Producto(rs.getInt("ID"),
						rs.getString("DESCRIPCION"),
						rs.getDouble("PRECIO")));			
			}
		} catch (Exception e) {
			System.out.println("Error al consultar todos los productos");
			e.printStackTrace();
		} finally {
			if (con != null)
				cerrarConexion();
		}
		
		return lista;
	}
	
	public Producto buscarProducto(int id){
		Producto encontrado = null;
		
		try {
			abrirConexion();
			
			String sql = "select * from PRODUCTOS where ID=?";
			PreparedStatement stm = con.prepareStatement(sql);
			stm.setInt(1, id);
			ResultSet rs = stm.executeQuery();
			
			if (rs.next()) {
				encontrado = new Producto(rs.getInt("ID"),
						rs.getString("DESCRIPCION"),
						rs.getDouble("PRECIO"));			
			}
		} catch (Exception e) {
			System.out.println("Error al buscar el producto " + id);
			e.printStackTrace();
		} finally {
			if (con != null)
				cerrarConexion();
		}
		
		return encontrado;
	}
	
	private void abrirConexion() {
		
		try {
			Class.forName("org.h2.Driver");
			con = DriverManager.getConnection("jdbc:h2:~/test");
			
			// Crear la tabla
			Statement stm = con.createStatement();
			stm.executeUpdate("DROP TABLE PRODUCTOS if exists");
			String sql = "CREATE TABLE PRODUCTOS " +
					"(ID INTEGER not NULL, "
					+ "DESCRIPCION VARCHAR(45), "
					+ "PRECIO DOUBLE,"
					+ "PRIMARY KEY (ID) )";
			stm.executeUpdate(sql);
			
			// Crear 5 productos en la tabla
			PreparedStatement pst = con.prepareStatement("insert into PRODUCTOS values (?,?,?)");
			for (int i=1; i<=5; i++) {
				pst.setInt(1, i);
				pst.setString(2, "Producto " + i);
				pst.setDouble(3, i*100);
				pst.executeUpdate();
			}
			
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}
	
	private void cerrarConexion() {
		try {
			con.close();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

}
