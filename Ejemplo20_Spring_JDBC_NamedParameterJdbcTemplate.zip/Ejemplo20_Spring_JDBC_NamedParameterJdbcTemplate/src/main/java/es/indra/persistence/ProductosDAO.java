package es.indra.persistence;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.jdbc.core.RowMapper;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;

import es.indra.models.Producto;

public class ProductosDAO {

	private NamedParameterJdbcTemplate plantilla;
	private RowMapper<Producto> mapeadorProducto;

	public List<Producto> consultarTodos() {
		return plantilla.query("select * from PRODUCTOS", mapeadorProducto);
	}

	public Producto buscarProducto(int id) {
		Map<String, Object> parametros = new HashMap<String, Object>();
		parametros.put("codigo", id);
		return plantilla.queryForObject("select * from PRODUCTOS where ID=:codigo", parametros, mapeadorProducto);
	}

	public void crearTabla() {
		// Crear la tabla
		plantilla.update("DROP TABLE PRODUCTOS if exists", (Map<String, Object>) null);
		String sql = "CREATE TABLE PRODUCTOS " + "(ID INTEGER not NULL, " + "DESCRIPCION VARCHAR(45), "
				+ "PRECIO DOUBLE," + "PRIMARY KEY (ID) )";
		plantilla.update(sql, (Map<String, Object>) null);

		// Crear 5 productos en la tabla
		sql = "insert into PRODUCTOS values (:codigo, :desc, :pre)";
		for (int i = 1; i <= 5; i++) {
			Map<String, Object> parametros = new HashMap<String, Object>();
			parametros.put("codigo", i);
			parametros.put("desc", "Producto " + i);
			parametros.put("pre", i * 100);
			plantilla.update(sql, parametros);
		}
	}

	public NamedParameterJdbcTemplate getPlantilla() {
		return plantilla;
	}

	public void setPlantilla(NamedParameterJdbcTemplate plantilla) {
		this.plantilla = plantilla;
	}

	public RowMapper<Producto> getMapeadorProducto() {
		return mapeadorProducto;
	}

	public void setMapeadorProducto(RowMapper<Producto> mapeadorProducto) {
		this.mapeadorProducto = mapeadorProducto;
	}

}
