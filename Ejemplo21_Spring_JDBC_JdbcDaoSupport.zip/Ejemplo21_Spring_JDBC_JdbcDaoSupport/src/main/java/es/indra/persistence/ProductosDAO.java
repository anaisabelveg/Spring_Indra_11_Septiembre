package es.indra.persistence;

import java.util.List;

import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.jdbc.core.support.JdbcDaoSupport;

import es.indra.models.Producto;

public class ProductosDAO extends JdbcDaoSupport {

	private RowMapper<Producto> mapeadorProducto;

	public List<Producto> consultarTodos() {
		return getJdbcTemplate().query("select * from PRODUCTOS", mapeadorProducto);
	}

	public Producto buscarProducto(int id) {
		return getJdbcTemplate().queryForObject("select * from PRODUCTOS where ID=?", mapeadorProducto, id);
	}

	public void crearTabla() {
		// Crear la tabla
		getJdbcTemplate().update("DROP TABLE PRODUCTOS if exists");
		String sql = "CREATE TABLE PRODUCTOS " + "(ID INTEGER not NULL, " + "DESCRIPCION VARCHAR(45), "
				+ "PRECIO DOUBLE," + "PRIMARY KEY (ID) )";
		getJdbcTemplate().update(sql);

		// Crear 5 productos en la tabla
		sql = "insert into PRODUCTOS values (?,?,?)";
		for (int i = 1; i <= 5; i++) {
			getJdbcTemplate().update(sql, i, "Producto " + i, i * 100);
		}
	}

	public RowMapper<Producto> getMapeadorProducto() {
		return mapeadorProducto;
	}

	public void setMapeadorProducto(RowMapper<Producto> mapeadorProducto) {
		this.mapeadorProducto = mapeadorProducto;
	}

}
