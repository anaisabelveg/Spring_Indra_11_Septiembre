package es.indra.config;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.jdbc.datasource.DriverManagerDataSource;

import es.indra.models.Producto;
import es.indra.persistence.MapeadorProducto;
import es.indra.persistence.ProductosDAO;

@Configuration
public class JavaConfig {
	
	@Bean
	public DriverManagerDataSource miDataSource() {
		DriverManagerDataSource dataSource = new DriverManagerDataSource();
		dataSource.setDriverClassName("org.h2.Driver");
		dataSource.setUrl("jdbc:h2:~/test");
		return dataSource;
	}
		
	@Bean
	public RowMapper<Producto> mapeadorProducto(){
		return new MapeadorProducto();
	}
	
	@Bean
	public ProductosDAO dao() {
		ProductosDAO dao = new ProductosDAO();
		dao.setDataSource(miDataSource());
		dao.setMapeadorProducto(mapeadorProducto());
		return dao;
	}

}
