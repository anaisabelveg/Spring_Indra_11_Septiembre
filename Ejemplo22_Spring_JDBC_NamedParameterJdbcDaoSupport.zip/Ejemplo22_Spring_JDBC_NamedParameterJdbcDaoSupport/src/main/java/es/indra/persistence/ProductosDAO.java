package es.indra.persistence;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.jdbc.core.RowMapper;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcDaoSupport;

import es.indra.models.Producto;

public class ProductosDAO extends NamedParameterJdbcDaoSupport{

	private RowMapper<Producto> mapeadorProducto;

	public List<Producto> consultarTodos() {
		return getNamedParameterJdbcTemplate().query("select * from PRODUCTOS", mapeadorProducto);
	}

	public Producto buscarProducto(int id) {
		Map<String, Object> parametros = new HashMap<String, Object>();
		parametros.put("codigo", id);
		return getNamedParameterJdbcTemplate().queryForObject("select * from PRODUCTOS where ID=:codigo", parametros, mapeadorProducto);
	}

	public void crearTabla() {
		// Crear la tabla
		getNamedParameterJdbcTemplate().update("DROP TABLE PRODUCTOS if exists", (Map<String, Object>) null);
		String sql = "CREATE TABLE PRODUCTOS " + "(ID INTEGER not NULL, " + "DESCRIPCION VARCHAR(45), "
				+ "PRECIO DOUBLE," + "PRIMARY KEY (ID) )";
		getNamedParameterJdbcTemplate().update(sql, (Map<String, Object>) null);

		// Crear 5 productos en la tabla
		sql = "insert into PRODUCTOS values (:codigo, :desc, :pre)";
		for (int i = 1; i <= 5; i++) {
			Map<String, Object> parametros = new HashMap<String, Object>();
			parametros.put("codigo", i);
			parametros.put("desc", "Producto " + i);
			parametros.put("pre", i * 100);
			getNamedParameterJdbcTemplate().update(sql, parametros);
		}
	}


	public RowMapper<Producto> getMapeadorProducto() {
		return mapeadorProducto;
	}

	public void setMapeadorProducto(RowMapper<Producto> mapeadorProducto) {
		this.mapeadorProducto = mapeadorProducto;
	}

}
