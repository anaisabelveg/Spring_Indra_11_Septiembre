package es.indra;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

import es.indra.models.Producto;
import es.indra.persistence.ProductosDAO;

@SpringBootApplication
public class AppMain implements CommandLineRunner{
	
	@Autowired
	private ProductosDAO dao;

	public static void main(String[] args) {
		SpringApplication.run(AppMain.class, args);
	}

	@Override
	public void run(String... args) throws Exception {
		
		// Crear la tabla y los datos iniciales
		dao.crearTabla();
		
		System.out.println("---------- Alta producto ---------");
		dao.altaProducto(new Producto(6, "Prueba", 66));
		
		System.out.println("---------- Todos los productos ---------");
		dao.consultarTodos().forEach(System.out::println);
		
		System.out.println("---------- Buscar un producto ----------");
		System.out.println("Encontrado " + dao.buscarProducto(3));
		
	}

}
