package es.indra.persistence;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

import es.indra.models.Producto;

public class MapeadorProducto implements RowMapper<Producto>{

	@Override
	public Producto mapRow(ResultSet rs, int rowNum) throws SQLException {
		Producto producto = new Producto(rs.getInt("ID"),
				rs.getString("DESCRIPCION"),
				rs.getDouble("PRECIO"));
		return producto;
	}

}
