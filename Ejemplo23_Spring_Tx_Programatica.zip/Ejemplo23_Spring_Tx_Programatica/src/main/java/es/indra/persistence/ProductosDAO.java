package es.indra.persistence;

import java.util.List;

import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.transaction.TransactionStatus;
import org.springframework.transaction.support.TransactionCallbackWithoutResult;
import org.springframework.transaction.support.TransactionTemplate;

import es.indra.models.Producto;

public class ProductosDAO {

	private JdbcTemplate plantilla;
	private RowMapper<Producto> mapeadorProducto;
	private TransactionTemplate txTemplate;


	public List<Producto> consultarTodos() {
		return plantilla.query("select * from PRODUCTOS", mapeadorProducto);	
	}

	public Producto buscarProducto(int id) {
		return plantilla.queryForObject("select * from PRODUCTOS where ID=?", mapeadorProducto, id);
	}
	
	public void altaProducto(Producto nuevo) {
		
		txTemplate.execute(new TransactionCallbackWithoutResult() {
			
			@Override
			protected void doInTransactionWithoutResult(TransactionStatus status) {
				
				try {
					String sql = "insert into PRODUCTOS values (?,?,?)";
					
					// Producto bueno
					plantilla.update(sql, nuevo.getID(), nuevo.getDescripcion(), nuevo.getPrecio());
					
					// Producto malo, erroneo
					plantilla.update(sql, 3, "Producto erroneo", 33);
					
					System.out.println("Se efectua el commit");
				} catch (Exception e) {
					// Ordenamos el rollback
					status.setRollbackOnly();
					System.out.println("Se hace el rollback");
					e.printStackTrace();
				}
				
			}
		});
		
	}

	public void crearTabla() {
		// Crear la tabla
		plantilla.update("DROP TABLE PRODUCTOS if exists");
		String sql = "CREATE TABLE PRODUCTOS " + "(ID INTEGER not NULL, " + "DESCRIPCION VARCHAR(45), "
				+ "PRECIO DOUBLE," + "PRIMARY KEY (ID) )";
		plantilla.update(sql);

		// Crear 5 productos en la tabla
		sql = "insert into PRODUCTOS values (?,?,?)";
		for (int i = 1; i <= 5; i++) {
			plantilla.update(sql, i, "Producto " + i, i * 100);
		}
	}

	
	
	public TransactionTemplate getTxTemplate() {
		return txTemplate;
	}

	public void setTxTemplate(TransactionTemplate txTemplate) {
		this.txTemplate = txTemplate;
	}

	public JdbcTemplate getPlantilla() {
		return plantilla;
	}

	public void setPlantilla(JdbcTemplate plantilla) {
		this.plantilla = plantilla;
	}

	public RowMapper<Producto> getMapeadorProducto() {
		return mapeadorProducto;
	}

	public void setMapeadorProducto(RowMapper<Producto> mapeadorProducto) {
		this.mapeadorProducto = mapeadorProducto;
	}

}
