package es.indra.config;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.ImportResource;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.jdbc.datasource.DataSourceTransactionManager;
import org.springframework.jdbc.datasource.DriverManagerDataSource;
import org.springframework.transaction.support.TransactionTemplate;

import es.indra.models.Producto;
import es.indra.persistence.MapeadorProducto;
import es.indra.persistence.ProductosDAO;

@Configuration
public class JavaConfig {
	
	// El bean TransactionManager siempre es obligatorio
	// independientemente del modelo de Tx elegido
	@Bean
	public DataSourceTransactionManager txManager() {
		DataSourceTransactionManager txManager = new DataSourceTransactionManager();
		txManager.setDataSource(miDataSource());
		return txManager;
	}
	
	@Bean
	public DriverManagerDataSource miDataSource() {
		DriverManagerDataSource dataSource = new DriverManagerDataSource();
		dataSource.setDriverClassName("org.h2.Driver");
		dataSource.setUrl("jdbc:h2:~/test");
		return dataSource;
	}
	
	@Bean
	public JdbcTemplate template() {
		JdbcTemplate template = new JdbcTemplate();
		template.setDataSource(miDataSource());
		return template;
	}
	
	@Bean
	public RowMapper<Producto> mapeadorProducto(){
		return new MapeadorProducto();
	}
	
	@Bean
	public ProductosDAO dao() {
		ProductosDAO dao = new ProductosDAO();
		dao.setPlantilla(template());
		dao.setMapeadorProducto(mapeadorProducto());
		return dao;
	}

}
