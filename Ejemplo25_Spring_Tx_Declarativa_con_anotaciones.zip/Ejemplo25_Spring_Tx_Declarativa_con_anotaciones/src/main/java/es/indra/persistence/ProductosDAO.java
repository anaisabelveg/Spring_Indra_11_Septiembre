package es.indra.persistence;

import java.sql.SQLException;
import java.util.List;

import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.transaction.annotation.Isolation;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import es.indra.models.Producto;

public class ProductosDAO {

	private JdbcTemplate plantilla;
	private RowMapper<Producto> mapeadorProducto;

	public List<Producto> consultarTodos() {
		return plantilla.query("select * from PRODUCTOS", mapeadorProducto);
	}

	public Producto buscarProducto(int id) {
		return plantilla.queryForObject("select * from PRODUCTOS where ID=?", mapeadorProducto, id);
	}

	@Transactional(propagation = Propagation.REQUIRED,
			isolation = Isolation.SERIALIZABLE,
			rollbackFor = SQLException.class)
	public void altaProducto(Producto nuevo) {

		String sql = "insert into PRODUCTOS values (?,?,?)";

		// Producto bueno
		plantilla.update(sql, nuevo.getID(), nuevo.getDescripcion(), nuevo.getPrecio());

		// Producto malo, erroneo
		plantilla.update(sql, 3, "Producto erroneo", 33);

		System.out.println("Se efectua el commit");

	}

	public void crearTabla() {
		// Crear la tabla
		plantilla.update("DROP TABLE PRODUCTOS if exists");
		String sql = "CREATE TABLE PRODUCTOS " + "(ID INTEGER not NULL, " + "DESCRIPCION VARCHAR(45), "
				+ "PRECIO DOUBLE," + "PRIMARY KEY (ID) )";
		plantilla.update(sql);

		// Crear 5 productos en la tabla
		sql = "insert into PRODUCTOS values (?,?,?)";
		for (int i = 1; i <= 5; i++) {
			plantilla.update(sql, i, "Producto " + i, i * 100);
		}
	}

	public JdbcTemplate getPlantilla() {
		return plantilla;
	}

	public void setPlantilla(JdbcTemplate plantilla) {
		this.plantilla = plantilla;
	}

	public RowMapper<Producto> getMapeadorProducto() {
		return mapeadorProducto;
	}

	public void setMapeadorProducto(RowMapper<Producto> mapeadorProducto) {
		this.mapeadorProducto = mapeadorProducto;
	}

}
