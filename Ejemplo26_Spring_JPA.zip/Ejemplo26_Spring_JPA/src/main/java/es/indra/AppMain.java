package es.indra;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import es.indra.models.Producto;
import es.indra.persistence.ProductosDAO;

@SpringBootApplication
public class AppMain implements CommandLineRunner {

	@Autowired
	private ProductosDAO dao;

	public static void main(String[] args) {
		SpringApplication.run(AppMain.class, args);
	}

	@Override
	public void run(String... args) throws Exception {

		System.out.println("---------- Alta producto ---------");
		for(int i=1; i<=5; i++) {
			dao.altaProducto(new Producto(i, "Producto " + i, i*100));
		}
		
		
		System.out.println("---------- Todos los productos ---------");
		dao.consultarTodos().forEach(System.out::println);

		System.out.println("---------- Buscar un producto ----------");
		System.out.println("Encontrado " + dao.buscarProducto(3));

	}

}
