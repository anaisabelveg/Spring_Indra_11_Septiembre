package es.indra.config;

import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import es.indra.persistence.ProductosDAO;

@Configuration
public class JavaConfig {
	
	@Bean
	public EntityManagerFactory emf() {
		return Persistence.createEntityManagerFactory("PU");
	}
	
	@Bean
	public ProductosDAO dao() {
		ProductosDAO dao = new ProductosDAO();
		dao.setEmf(emf());
		return dao;
	}

}
