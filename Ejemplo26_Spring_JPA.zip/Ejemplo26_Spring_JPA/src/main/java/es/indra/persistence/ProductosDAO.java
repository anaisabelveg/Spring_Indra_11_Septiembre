package es.indra.persistence;

import java.sql.SQLException;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;

import org.springframework.transaction.annotation.Isolation;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import es.indra.models.Producto;

public class ProductosDAO {

	private EntityManagerFactory emf;

	public List<Producto> consultarTodos() {
		EntityManager em = emf.createEntityManager();
		List<Producto> lista = em.createQuery("select p from Producto p").getResultList();
		em.close();
		return lista;
	}

	public Producto buscarProducto(int id) {
		EntityManager em = emf.createEntityManager();
		Producto encontrado = em.find(Producto.class, id);
		em.close();
		return encontrado;
	}

	@Transactional
	public void altaProducto(Producto nuevo) {
		
		EntityManager em = emf.createEntityManager();
		EntityTransaction et = em.getTransaction();
		
		try {
			et.begin();
			em.persist(nuevo);
			et.commit();
		} catch (Exception e) {
			e.printStackTrace();
			et.rollback();
		}
	
		em.close();

	}

	public EntityManagerFactory getEmf() {
		return emf;
	}

	public void setEmf(EntityManagerFactory emf) {
		this.emf = emf;
	}


}
