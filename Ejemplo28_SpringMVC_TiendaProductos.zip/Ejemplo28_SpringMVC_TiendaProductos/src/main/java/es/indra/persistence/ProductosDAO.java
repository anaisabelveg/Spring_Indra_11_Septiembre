package es.indra.persistence;

import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Repository;

import es.indra.models.Producto;

@Repository
public class ProductosDAO {
	
	private List<Producto> lista = new ArrayList<>();
	
	public ProductosDAO() {
		// Agregar 5 productos iniciales a la lista
		lista.add(new Producto(1, "Pantalla", 129.95));
		lista.add(new Producto(2, "Scanner", 200));
		lista.add(new Producto(3, "Teclado", 35));
		lista.add(new Producto(4, "Raton", 22));
		lista.add(new Producto(5, "Impresora", 87.30));
	}
	
	public List<Producto> consultarTodos(){
		return lista;
	}

}
