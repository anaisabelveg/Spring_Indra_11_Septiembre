package es.indra.controllers;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;

import es.indra.business.Carrito;

@Controller
@Scope("session")
public class CarritoController{
	
	@Autowired
	private Carrito miCarro;
	
	
	@GetMapping(value = "/comprar")
	public String comprarProducto(int id) {
		miCarro.agregarProducto(id);
		return "mostrarCarrito";
	}
	
	@GetMapping(value = "/sacar")
	public String sacarProducto(int id) {
		miCarro.sacarProducto(id);
		return "mostrarCarrito";
	}

}
