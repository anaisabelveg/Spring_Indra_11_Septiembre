package es.indra.models;

import java.io.Serializable;

import javax.validation.constraints.DecimalMin;
import javax.validation.constraints.Digits;
import javax.validation.constraints.Size;

public class Producto implements Serializable{
		
	private static final long serialVersionUID = -6771407325304461209L;
	
	@Digits(integer = 3, fraction = 0, message = "Debe tener maximo 3 numeros enteros")
	private int ID;
	
	@Size(min = 3, max = 20, message = "Debe tener entre 3 y 20 caracteres")
	private String descripcion;
	
	@Digits(integer = 4, fraction = 2, message = "Debe tener maximo 6 digitos con 2 decimales")
	@DecimalMin(value = "1", message = "Precio minimo 1€")
	private double precio;
	
	public Producto() {
		// TODO Auto-generated constructor stub
	}

	public Producto(int iD, String descripcion, double precio) {
		super();
		ID = iD;
		this.descripcion = descripcion;
		this.precio = precio;
	}

	public int getID() {
		return ID;
	}

	public void setID(int iD) {
		ID = iD;
	}

	public String getDescripcion() {
		return descripcion;
	}

	public void setDescripcion(String descripcion) {
		this.descripcion = descripcion;
	}

	public double getPrecio() {
		return precio;
	}

	public void setPrecio(double precio) {
		this.precio = precio;
	}

	@Override
	public String toString() {
		return "Producto [ID=" + ID + ", descripcion=" + descripcion + ", precio=" + precio + "]";
	}
	
	

}
