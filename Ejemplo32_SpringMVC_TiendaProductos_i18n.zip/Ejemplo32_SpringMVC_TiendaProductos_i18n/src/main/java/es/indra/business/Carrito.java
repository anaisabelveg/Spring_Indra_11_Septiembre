package es.indra.business;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Service;

import es.indra.models.Producto;
import es.indra.persistence.ProductosDAO;

@Service("miCarro")
@Scope("session")
public class Carrito implements Serializable{

	private static final long serialVersionUID = 655623027735466513L;
	
	private List<Producto> contenido = new ArrayList<>();
	private double importe;
	
	@Autowired
	private ProductosDAO dao;
	
	
	public void agregarProducto(int id) {
		Producto producto = dao.buscarProducto(id).get();
		contenido.add(producto);
		importe += producto.getPrecio();
	}
	
	public void sacarProducto(int id) {
		Producto eliminar = null;
		
		for (Producto producto : contenido) {
			if (id == producto.getID()) {
				eliminar = producto;
				break;
			}
		}
		
		contenido.remove(eliminar);
		importe -= eliminar.getPrecio();
	}
	
	public List<Producto> getContenido() {
		return contenido;
	}
	
	public double getImporte() {
		return importe;
	}

}
