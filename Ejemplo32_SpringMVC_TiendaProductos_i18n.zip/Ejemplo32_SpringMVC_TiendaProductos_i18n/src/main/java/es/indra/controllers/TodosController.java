package es.indra.controllers;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;

import es.indra.models.Producto;
import es.indra.persistence.ProductosDAO;

@Controller
@RequestMapping("/")
public class TodosController {
	
	@Autowired
	private ProductosDAO dao;
	
	@RequestMapping(value = "todos")
	public String execute(Model modelo) {
		List<Producto> lista = dao.consultarTodos();
		modelo.addAttribute("lista", lista);
		return "mostrarTodos";
	}

}
