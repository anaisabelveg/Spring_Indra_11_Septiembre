package es.indra.models;

import java.util.List;
import java.util.Map;
import java.util.Properties;
import java.util.Set;

public class Empresa {

	private List<Empleado> empleados;
	private Set<String> proyectos;
	private Empleado[] equipo;
	private Map<String, Empleado> jefesProyecto;
	private Properties emails;

	// Si yo no pongo ningun constructor, Java añade el constructor por defecto
	public List<Empleado> getEmpleados() {
		return empleados;
	}

	public void setEmpleados(List<Empleado> empleados) {
		this.empleados = empleados;
	}

	public Set<String> getProyectos() {
		return proyectos;
	}

	public void setProyectos(Set<String> proyectos) {
		this.proyectos = proyectos;
	}

	public Empleado[] getEquipo() {
		return equipo;
	}

	public void setEquipo(Empleado[] equipo) {
		this.equipo = equipo;
	}

	public Map<String, Empleado> getJefesProyecto() {
		return jefesProyecto;
	}

	public void setJefesProyecto(Map<String, Empleado> jefesProyecto) {
		this.jefesProyecto = jefesProyecto;
	}

	public Properties getEmails() {
		return emails;
	}

	public void setEmails(Properties emails) {
		this.emails = emails;
	}

}
