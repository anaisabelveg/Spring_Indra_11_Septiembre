package es.indra;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class AppMain {

	public static void main(String[] args) {
		// Levantar el contexto de Spring
		// Leer applicationContext.xml y por cada bean declarado genera
		// la instancia y la guarda en el contenedor
		ApplicationContext contenedor = new ClassPathXmlApplicationContext("applicationContext.xml");

		// org.springframework.beans.factory.BeanIsAbstractException: Error creating bean with name 'plantilla': Bean definition is abstract
		// System.out.println(contenedor.getBean("plantilla"));

		System.out.println(contenedor.getBean("empleado1"));
		System.out.println(contenedor.getBean("empleado2"));
		

	}

}
