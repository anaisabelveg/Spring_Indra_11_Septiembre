package es.indra;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import es.indra.business.Contabilidad;

public class AppMain {

	public static void main(String[] args) {
		// Levantar el contexto de Spring
		// Leer applicationContext.xml y por cada bean declarado genera
		// la instancia y la guarda en el contenedor
		ApplicationContext appCtx = new ClassPathXmlApplicationContext("applicationContext.xml");
		
		// Recuperar el bean contabilidad
		Contabilidad contabilidad = (Contabilidad) appCtx.getBean("contabilidad");
		
		contabilidad.movimiento("Pago alquiler");
		contabilidad.movimiento("Amortizacion de maquinaria");
		
		
		// Recuperar el libro contable
		Contabilidad libro = appCtx.getBean("libro", Contabilidad.class);
		libro.movimiento("Pago de nominas");
		libro.movimiento("Compra de material");
	}

}
