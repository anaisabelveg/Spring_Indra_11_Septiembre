package es.indra;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import es.indra.models.Empleado;

public class AppMain {

	public static void main(String[] args) {
		// Levantar el contexto de Spring
		// Leer applicationContext.xml y por cada bean declarado genera
		// la instancia y la guarda en el contenedor
		ApplicationContext contenedor = new ClassPathXmlApplicationContext("applicationContext.xml");
		
		Empleado emp1Singleton = contenedor.getBean("empleado1", Empleado.class);
		Empleado emp2Singleton = contenedor.getBean("empleado1", Empleado.class);
		System.out.println(emp1Singleton == emp2Singleton);
		
		Empleado emp1Prototype = contenedor.getBean("empleado2", Empleado.class);
		Empleado emp2Prototype = contenedor.getBean("empleado2", Empleado.class);
		System.out.println(emp1Prototype == emp2Prototype);

	}

}
