package es.indra;

import java.util.Arrays;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import es.indra.models.Empleado;
import es.indra.models.Empresa;

public class AppMain {

	public static void main(String[] args) {
		// Levantar el contexto de Spring
		// Leer applicationContext.xml y por cada bean declarado genera
		// la instancia y la guarda en el contenedor
		ApplicationContext contenedor = new ClassPathXmlApplicationContext("applicationContext.xml");
		
		Empresa empresa = contenedor.getBean("empresa", Empresa.class);
		
		System.out.println("------------- Empleados -----------");
		empresa.getEmpleados().forEach(System.out::println);
		
		System.out.println("------------- Proyectos -----------");
		empresa.getProyectos().forEach(System.out::println);
		
		System.out.println("------------- Equipo -------------");
		System.out.println(Arrays.toString(empresa.getEquipo()));  
		for (Empleado empl : empresa.getEquipo()) {
			System.out.println(empl);
		}
		
		System.out.println("------------ Jefes de proyecto -----------");
		empresa.getJefesProyecto().entrySet().forEach(System.out::println);
		
		System.out.println("------------ Emails -------------");
		empresa.getEmails().entrySet().forEach(System.out::println);
		
		

	}

}
